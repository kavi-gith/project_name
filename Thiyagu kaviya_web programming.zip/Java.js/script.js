
function tossCap() {
    const cap = document.getElementById('cap');
    cap.style.bottom = '150px';
    cap.style.transform = 'translateX(-50%) rotate(360deg)';

    setTimeout(() => {
        document.getElementById('message').classList.remove('hidden');
    }, 1000); 
}


function customizeECard() {
    const userMessage = prompt("Enter your congratulatory message:");
    document.getElementById('message').innerText = userMessage;
}


function openShareForm() {
    document.getElementById("registrationModal").style.display = "block";
}


function closeShareForm() {
    document.getElementById("registrationModal").style.display = "none";
}


function resetECard() {
    const cap = document.getElementById('cap');
    cap.style.bottom = '0';
    cap.style.transform = 'translateX(-50%) rotate(0deg)';
    document.getElementById('message').classList.add('hidden');
}


function toggleAnimation() {
    const cap = document.getElementById('cap');
    const capStyle = window.getComputedStyle(cap);

    if (capStyle.animationPlayState === 'paused') {
        cap.style.animationPlayState = 'running';
    } else {
        cap.style.animationPlayState = 'paused';
    }
}

function playBackgroundMusic() {
    const music = document.getElementById('backgroundMusic');
    music.play();
}

document.getElementById("shareForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
    const phoneNumber = document.getElementById("phoneNumber").value;
    const message = encodeURIComponent("Congratulations on your graduation! Here's a special e-card just for you");
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(whatsappURL, '_blank');
    closeShareForm(); 
});







